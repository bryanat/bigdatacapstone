function output string example

order_id,customer_id,customer_name,product_id,product_name,product_category,payment_type,qty,price,datetime,country,city,website,pay_id,success,failure_reason

Programmatically generated data: OrderId,qty,datetime,website,pay_id,success
Taken from data files:customer_id,customer_name,product_id,product_name,product_category,payment_type,country,city,website,failure_reason
                              ^paired^               ^----------joined-----------^                      ^paired^

failure_reason: ### 3 digit code to express type of failure

each person has a unique identifier
grace id: TGA
mark id: ZOR

order_id: TGALKNLIUD234N3,
          ZOR1101, ZOR1102214